package com.example.renoldhadihistorytidota2

data class tiaydata (
    var name : String = "",
    var overview : String ="",
    var Organizer : String = "",
    var  Winnerteam : String ="",
    var  VersionMap : String ="",
    var Location : String ="",
    var venue : String = "",
    var Dates : String ="",
    var Teams : String ="",
    var Prizepool : String ="",
    var  photo : Int = 0

)

