package com.example.renoldhadihistorytidota2

object Objektiay {
    private var datatiay = arrayOf(
        arrayOf(
            "The International Dota 2 Championships 2011",
            "The International Dota 2 Championships adalah turnamen offline eliminasi ganda yang diselenggarakan oleh Valve dan berlangsung selama lima hari pameran dagang GamesCom di Cologne, 2011.Tempat tersebut digunakan oleh Valve untuk mengungkap Dota 2 kepada audiens di seluruh dunia dan menawarkan kumpulan hadiah $ 1,6 juta. Valve mengundang 16 team dari seluruh dunia.Grand Final Na`Vi mengalahkan EHOME dengan dengan skor 3-1 , dan membawa pulang trofi juara The International pertama",
            "Valve",
            "Natus Vincere",
            "6.72d",
            "Germany , Cologne",
            "Koelnmesse",
            "Aug 17 - 21, 2011",
            "16",
            "$1.600.000 USD",
            R.drawable.ts_one


        ),
        arrayOf(
            "The International Dota 2 Championships 2012",
            "The International Dota 2 Championships 2012 adalah turnamen Dota 2 terbesar di dunia, berdasarkan pot hadiah. Acara tersebut diadakan dari tanggal 26 Agustus hingga 2 September 2012, di Benaroya Hall di Seattle, Washington. Ajang ini merupakan turnamen kedua yang menyandang nama 'The International'. Internasional pertama diadakan pada 2011 dan berfungsi sebagai tanggal peluncuran Dota 2 beta.Grand Final Invictus Gaming mengalah juara bertahan Na'VI dengan skor 3-1 dan Invictus Gaming Berhak atas trofi ke dua TI 2012",
            "Valve",
            "Invictus Gaming",
            "6.74",
            "United State , Seattle",
            "Benaroya Hall",
            "Aug 26 - sep 2 , 2012",
            "16",
            "$1.600.000 USD",
            R.drawable.ts_two
        ),
        arrayOf(
            "The International Dota 2 Championships 2013",
            "The International Dota 2 Championships 2013 diadakan di Seattle, Washington, di Benaroya Hall. Itu adalah turnamen Dota 2 terbesar di dunia, berdasarkan kumpulan hadiah. Acara tersebut diadakan dari tanggal 8 Agustus hingga 11 Agustus 2013, di Benaroya Hall di Seattle, Washington. Ajang ini merupakan turnamen ketiga yang menyandang nama 'The International.Di Grand Final kali ini menggunakan 5 round untuk menentukan pemenang dan di  grand final Alliance mampu mengalah na'vi dengan skor 3-2",
            "Valve",
            "Alliance",
            "6.78",
            "United State , Seattle",
            "Benaroya Hall",
            "Aug 2-11 ,2013",
            "16",
            "$2.874.380 USD",
            R.drawable.ts_three
        ),
        arrayOf(
            "The International Dota 2 Championships 2014",
            "The International Dota 2 Championships 2014 diadakan di Seattle, Washington. Turnamen ini adalah edisi keempat The International, dan ini adalah tahun ketiga berturut-turut turnamen tersebut diselenggarakan di Seattle. Berbeda dengan dua tahun sebelumnya, turnamen ini diadakan di KeyArena, arena serba guna di Seattle Center dengan total kapasitas tempat duduk lebih dari 17.000.Sebanyak 16 tim berkompetisi di acara utama turnamen. 11 di antaranya menerima undangan langsung, sementara 4 tim harus lolos melalui kualifikasi regional terpisah, dengan runner up di kualifikasi tersebut mendapatkan satu kesempatan terakhir untuk bersaing memperebutkan tempat terakhir di turnamen utama.Di GrandFinal Team Newbiee dari china dapat mengalah kan team china lain nya yaitu Vici Gmaing dengan skor 3-1",
            "Valve",
            "Team Newbiee",
            "6.81b",
            "United State , Seattle",
            "KeyArena",
            "jul 8-21 , 2014 ",
            "16",
            "$10.923.977 USD",
            R.drawable.ts_four

        ),
        arrayOf(
            "The International Dota 2 Championships 2015",
            "The International Dota 2 Championships 2015 adalah edisi tahunan kelima The International. Turnamen ini diselenggarakan di Seattle untuk tahun keempat berturut-turut, dan tahun kedua berturut-turut dimana Acara Utama berlangsung di KeyArena, arena multi-tujuan di Seattle Center dengan total kapasitas tempat duduk lebih dari 17.000. Di Grand Final Evil Geniuses dapat mengalah kan team CDEC Gaming dengan skor 3-1 dan Evil Geniuses berhak mendapat trofi TI season ke 5",
            "Valve",
            "Evil genius",
            "6.84c",
            "United State , Seattle",
            "KeyArena",
            "jul 27 - aug 8,2015",
            "16",
            "$18.429.613 USD",
            R.drawable.ts_five
        ),
        arrayOf(
            "The International Dota 2 Championships 2016",
            "The International Dota 2 Championships 2016 adalah Major keempat musim 2016 dan edisi tahunan keenam The International. Turnamen ini diselenggarakan di Seattle untuk tahun kelima berturut-turut; Ini adalah tahun ketiga berturut-turut bahwa Acara Utama berlangsung di KeyArena, arena multi-purpose di Seattle Center dengan total kapasitas tempat duduk lebih dari 17.000.Di Grand Final Wings Gaming dapat mengalah kan Digital Chaos Dengan skor 3-1 dan menempatkan Wings Gaming sebagai juara TI 2016.",
            "Valve",
            "Wings Gaming",
            "6.88b",
            "United State , Seattle",
            "KeyArena",
            "Aug 2 -13 , 2016",
            "16",
            "$20.770.460 USD",
            R.drawable.ts_six

        ),
        arrayOf(
            "The International Dota 2 Championships 2017",
            "The International Dota 2 Championships 2017 adalah Major ketiga musim 2017 dan edisi tahunan ketujuh The International. Turnamen ini diselenggarakan di Seattle selama enam tahun berturut-turut. Acara Utama berlangsung untuk keempat kalinya berturut-turut di KeyArena, arena serbaguna di Seattle Center dengan total kapasitas tempat duduk lebih dari 17.000.Di Grand Final Team Liquid mengalah kan Newbiee dari china dengan skor 3-0 tanpa balas dan Team Liqiud menjadi juara TI 2017",
            "Valve",
            "Team Liquid",
            "7.06e",
            "United State , Seattle",
            "KeyArena",
            "Aug 2-12 , 2017",
            "16",
            "$24.787.916 USD",
            R.drawable.ts_seven


        ),
        arrayOf(
            "The International Dota 2 Championships 2018",
            "The International Dota 2 Championships 2018 adalah turnamen penutup Dota Pro Circuit dan edisi tahunan kedelapan The International. Turnamen ini akan diadakan di tanah Kanada untuk pertama kalinya, saat pindah ke Rogers Arena di Vancouver, Kanada. Untuk pertama kalinya, sistem poin berdasarkan Major dan Minors yang disponsori resmi digunakan untuk menentukan undangan ke The International.Dan Di grand final OG dapat Mengalahkan PSG.LGD dengan skor tipis 3-2 dan OG berhak mendapatkan trofi TI 2018",
            "Valve",
            "OG",
            "7.19",
            "Canada , Vancouver",
            "Rogers Arena",
            "Aug 15 - 25 , 2018",
            "18",
            "$25.532.177 USD",
            R.drawable.ts_eigth

        ),
        arrayOf(
            "The International Dota 2 Championships 2019",
            "The International Dota 2 Championships 2019 adalah turnamen penutup Dota Pro Circuit dan edisi tahunan kesembilan The International. Turnamen ini akan digelar di tanah Cina untuk pertama kalinya, seiring dengan perpindahan ke Mercedes-Benz Arena di Shanghai.Di Grand Final OG mampu mengalah kan Team Liquid dengan skor 3-1 dan OG tim pertama yang menjadi juara 2x berturut-turut yaitu 2018 dan 2019",
            "Valve",
            "OG",
            "7.22f",
            "China , Shangai",
            "Mecedes-Benz Arena",
            "18",
            "$34.330.068 USD",
            R.drawable.ts_nine
        ),
        arrayOf(
            "The International Dota 2 Championships 2020",
            "Kabar mengecewakan datang dari Dota 2. Ya, Valve, pengembang gim Dota 2, harus mengumumkan bahwa The International (TI) 2020 harus ditunda, Kabar mengecewakan ini diumumkan oleh Valve lewat situs resmi mereka. Pandemi virus corona yang tak kunjung berakhir mengharuskan Valve mengambil keputusan tersebut.The International 10 rencananya akan digelar di Ericsson Globe, Stockholm, Swedia. 18 tim akan bersaing untuk membawa pulang Aegis of Champions ",
            "Valve",
            "TBD",
            "-",
            "Stockholm, Swedia",
            "Ericsson Globe",
            "-",
            "-",
            R.drawable.ts_ten
        )

    )
    val listteay : ArrayList<tiaydata>
    get() {
        val list = arrayListOf<tiaydata>()
        for (n in datatiay) {
            val tiay = tiaydata()
            tiay.name = n[0] as String
            tiay.overview = n[1] as String
            tiay.Winnerteam = n[2] as String
            tiay.VersionMap = n[3] as String
            tiay.Location = n[4] as String
            tiay.venue = n[5] as String
            tiay.Dates = n[6] as String
            tiay.Teams = n [7] as String
            tiay.Prizepool = n[8] as String
            tiay.photo = n[9] as Int
            list.add(tiay)


        }
        return list
    }
}